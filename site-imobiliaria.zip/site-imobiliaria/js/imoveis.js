document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("listaImoveis");
  const imoveis = JSON.parse(localStorage.getItem("imoveis")) || [];
  const clientes = JSON.parse(localStorage.getItem("clientes")) || [];

  function buscarNomePorCPF(cpf) {
    const cliente = clientes.find(c => c.cpf === cpf);
    return cliente ? cliente.nome : "Não encontrado";
  }

  imoveis.forEach((imovel, index) => {
    const div = document.createElement("div");
    div.className = "imovel";

    const swiperId = `swiper-${index}`;

    const swiperHTML = `
      <div class="swiper" id="${swiperId}">
        <div class="swiper-wrapper">
          ${imovel.fotos.map(foto => `
            <div class="swiper-slide">
              <img src="${foto}" alt="Foto do imóvel">
            </div>
          `).join("")}
        </div>
        <div class="swiper-pagination"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
      </div>
    `;

    const html = `
      ${swiperHTML}
      <h3>${imovel.titulo}</h3>
      <p><strong>Tipo:</strong> ${imovel.tipo}</p>
      <p><strong>Finalidade:</strong> ${imovel.finalidade}</p>
      <p><strong>Valor:</strong> R$ ${imovel.valor.toFixed(2)}</p>
      <p><strong>IPTU:</strong> R$ ${imovel.iptu.toFixed(2)}</p>
      <p><strong>Quartos:</strong> ${imovel.quartos}</p>
      <p><strong>Banheiros:</strong> ${imovel.banheiros}</p>
      <p><strong>Vagas:</strong> ${imovel.vagas}</p>
      <p><strong>Proprietário:</strong> ${buscarNomePorCPF(imovel.proprietario)}</p>
      <p><strong>Inquilino:</strong> ${imovel.inquilino ? buscarNomePorCPF(imovel.inquilino) : "Nenhum"}</p>
      <p>${imovel.descricao}</p>
    `;

    div.innerHTML = html;
    lista.appendChild(div);

    // Inicializa o Swiper após a renderização
    setTimeout(() => {
      new Swiper(`#${swiperId}`, {
        loop: true,
        navigation: {
          nextEl: `#${swiperId} .swiper-button-next`,
          prevEl: `#${swiperId} .swiper-button-prev`,
        },
        pagination: {
          el: `#${swiperId} .swiper-pagination`,
          clickable: true,
        },
      });
    }, 0);
  });
});